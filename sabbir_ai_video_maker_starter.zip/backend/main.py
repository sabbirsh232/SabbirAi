from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from typing import List
import os
import tempfile

app = FastAPI(title="Sabbir AI Video Maker API")

@app.get("/")
def health():
    return {"status": "ok", "message": "Sabbir AI Video Maker backend is running"}

@app.post("/generate")
async def generate(
    script: str = Form(...),
    style: str = Form(...),
    images: List[UploadFile] = File(...)
):
    if not script.strip():
        raise HTTPException(status_code=400, detail="Script is required")
    if not images:
        raise HTTPException(status_code=400, detail="At least one image is required")

    # Provider integration goes here.
    # Keep all secret API keys in backend environment variables, never in the app.
    provider_key = os.getenv("VIDEO_PROVIDER_API_KEY")
    if not provider_key:
        return {
            "status": "not_configured",
            "message": (
                "ছবি ও স্ক্রিপ্ট সার্ভারে পৌঁছেছে। কিন্তু AI video provider এখনো "
                "সংযুক্ত করা হয়নি। VIDEO_PROVIDER_API_KEY সেট করে provider integration যোগ করুন।"
            ),
            "received_images": len(images),
            "selected_style": style
        }

    # TODO: Upload images to the selected provider, submit script/style,
    # poll the generation job, then return {"status":"completed","video_url":"https://..."}.
    return {
        "status": "provider_integration_needed",
        "message": "API key পাওয়া গেছে, কিন্তু নির্বাচিত provider-এর নির্দিষ্ট integration এখনো যোগ করা হয়নি।"
    }
