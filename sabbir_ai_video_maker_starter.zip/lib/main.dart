import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

void main() => runApp(const SabbirVideoApp());

class SabbirVideoApp extends StatelessWidget {
  const SabbirVideoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sabbir AI Video Maker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7C5CFC),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF10111A),
        useMaterial3: true,
      ),
      home: const CreateVideoPage(),
    );
  }
}

class CreateVideoPage extends StatefulWidget {
  const CreateVideoPage({super.key});

  @override
  State<CreateVideoPage> createState() => _CreateVideoPageState();
}

class _CreateVideoPageState extends State<CreateVideoPage> {
  // Change this to your deployed backend URL. Do not put provider API keys here.
  static const String apiBaseUrl = 'http://10.0.2.2:8000';

  final scriptController = TextEditingController();
  final picker = ImagePicker();
  final List<XFile> images = [];
  String style = '3D Cartoon';
  bool busy = false;
  String status = 'আপনার গল্প ও ছবি যোগ করে ভিডিও তৈরি শুরু করুন।';

  Future<void> pickImages() async {
    final selected = await picker.pickMultiImage(imageQuality: 85);
    if (selected.isNotEmpty) {
      setState(() => images.addAll(selected));
    }
  }

  Future<void> createVideo() async {
    if (scriptController.text.trim().isEmpty) {
      setState(() => status = 'আগে আপনার ভিডিওর স্ক্রিপ্ট লিখুন।');
      return;
    }
    if (images.isEmpty) {
      setState(() => status = 'কমপক্ষে একটি ছবি যোগ করুন।');
      return;
    }

    setState(() {
      busy = true;
      status = 'অনুরোধ পাঠানো হচ্ছে...';
    });

    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$apiBaseUrl/generate'),
      );
      request.fields['script'] = scriptController.text.trim();
      request.fields['style'] = style;

      for (final image in images) {
        request.files.add(await http.MultipartFile.fromPath('images', image.path));
      }

      final streamed = await request.send().timeout(const Duration(minutes: 3));
      final response = await http.Response.fromStream(streamed);
      final data = jsonDecode(response.body) as Map<String, dynamic>;

      setState(() {
        status = data['message']?.toString() ??
            data['detail']?.toString() ??
            'সার্ভার থেকে উত্তর পাওয়া গেছে।';
        if (data['video_url'] != null) {
          status = 'ভিডিও তৈরি হয়েছে: ${data['video_url']}';
        }
      });
    } catch (e) {
      setState(() {
        status = 'সার্ভারে সংযোগ করা যায়নি। Backend চালু আছে কি না এবং URL ঠিক আছে কি না দেখুন।';
      });
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    scriptController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sabbir AI Video Maker'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF4936A8), Color(0xFF202B59)],
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('আপনার গল্প, আপনার ভিডিও',
                    style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text('স্ক্রিপ্ট ও ছবি দিয়ে AI ভিডিও তৈরির শুরু করুন।'),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const Text('১. ভিডিওর স্ক্রিপ্ট', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextField(
            controller: scriptController,
            minLines: 5,
            maxLines: 9,
            decoration: const InputDecoration(
              hintText: 'এখানে গল্প বা ভিডিওর স্ক্রিপ্ট লিখুন...',
              border: OutlineInputBorder(),
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 20),
          const Text('২. ভিডিওর স্টাইল', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: style,
            decoration: const InputDecoration(border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: '3D Cartoon', child: Text('3D Cartoon')),
              DropdownMenuItem(value: '2D Animation', child: Text('2D Animation')),
              DropdownMenuItem(value: 'Realistic', child: Text('Realistic')),
              DropdownMenuItem(value: 'Anime', child: Text('Anime')),
              DropdownMenuItem(value: 'Cinematic', child: Text('Cinematic')),
            ],
            onChanged: (value) => setState(() => style = value ?? style),
          ),
          const SizedBox(height: 20),
          const Text('৩. ছবি যোগ করুন', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: pickImages,
            icon: const Icon(Icons.add_photo_alternate_outlined),
            label: const Text('মোবাইল থেকে ছবি নির্বাচন করুন'),
          ),
          if (images.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text('${images.length}টি ছবি নির্বাচন করা হয়েছে'),
            const SizedBox(height: 8),
            SizedBox(
              height: 95,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: images.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) => ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.file(File(images[index].path), width: 95, height: 95, fit: BoxFit.cover),
                ),
              ),
            ),
          ],
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: busy ? null : createVideo,
            icon: busy
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.movie_creation_outlined),
            label: Text(busy ? 'অপেক্ষা করুন...' : 'AI ভিডিও তৈরি করুন'),
            style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF1B1D2A),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(status),
          ),
          const SizedBox(height: 20),
          const Text(
            'নোট: এই প্রাথমিক সংস্করণে অ্যাপের ইন্টারফেস ও ছবি/স্ক্রিপ্ট পাঠানোর ব্যবস্থা আছে। আসল AI ভিডিও তৈরি চালু করতে backend-এ একটি ভিডিও AI সেবা সংযুক্ত করতে হবে।',
            style: TextStyle(color: Colors.white70, fontSize: 12),
          ),
        ],
      ),
    );
  }
}
