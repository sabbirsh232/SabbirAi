# Sabbir AI Video Maker — starter project

This is a starter Android app project for a script + image to video workflow.

## What works in this starter
- Flutter Android app UI
- Enter a script
- Choose a visual style (3D, 2D, realistic)
- Select one or more images from the phone
- Send a generation request to a backend endpoint
- Show the returned job status / video URL

## What is NOT yet connected
Actual AI video generation is not free or unlimited by default. The app needs a video-generation provider/API and its credentials. Keep provider keys on the backend, never inside the Android app. The backend currently returns a clear "provider not configured" response until you connect a provider.

## Requirements
- Flutter SDK (stable)
- Android Studio or VS Code with Flutter extension
- Android SDK
- Python 3.10+ for the optional backend

## Run the Android app
1. Install Flutter and Android Studio on a computer.
2. Create a Flutter project: `flutter create sabbir_ai_video_maker`
3. Replace the generated `pubspec.yaml` and `lib/main.dart` with the files in this folder.
4. Run `flutter pub get`
5. Start the backend (see below), then set `apiBaseUrl` in `lib/main.dart` to your backend address.
6. Run `flutter run` or build with `flutter build apk --release`.

## Run the backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

For a phone on the same Wi-Fi, use the computer's LAN IP in `apiBaseUrl`, e.g. `http://192.168.1.20:8000`.
For production, deploy the backend with HTTPS.

## Next development milestones
1. Connect a legitimate image-to-video provider.
2. Add secure image upload storage.
3. Add job polling and progress updates.
4. Add video preview, download, and FFmpeg-based audio/subtitle assembly.
5. Add authentication, quotas, and cost controls.

This project is a starting codebase, not a finished APK.
